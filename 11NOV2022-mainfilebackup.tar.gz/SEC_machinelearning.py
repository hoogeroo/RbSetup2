import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
from warnings import catch_warnings
from warnings import simplefilter
from sklearn.neural_network import MLPRegressor

'''
Read:
    https://towardsdatascience.com/a-conceptual-explanation-of-bayesian-model-based-hyperparameter-optimization-for-machine-learning-b8172278050f
    https://machinelearningmastery.com/what-is-bayesian-optimization/
    
'''

class ExptOptimiser():
    def __init__(self, params, doGo):
        self.fit_model = MLPRegressor()
        self.params = params
        
        self.doGo = doGo
        
        for p in self.params:
            if not hasattr(p,'history'): # Make sure we have space for an independent history for each parameter
                p.history=[]
        
        self.history = {'trials':[],  # This is history on a per-trial basis
                        'cost':[] }          # Parameter histories are attached to the relevant parameter.
        
    def cost_function(self, N, OD_peak):
        if (N < 0) or (OD_peak < 0): # Guarantees that faulty determinations of N, OD_peak won't be optimal
            return 1
        
        # See cost function form: https://arxiv.org/abs/2205.08057, page 3
        # Needed parameters for cost:
        alpha = 2 # normally 0.5 or 1
        normaliser_lowN = 2 / (1 + np.exp(1e3/N)) # avoid divergences at small N
        
        # cost calculation drawn from above paper
        cost = -normaliser_lowN * OD_peak**3 * N**(alpha - 1.8) # NOTE: negative so that cost can be minimised
        
        return cost
    
    def get_default_std(self, param):
        ptype = param.type
        
        if ptype is "A":
            std = 1
        elif ptype is "B":
            std = 2
            
        return std
    
    # 'surrogate', attempting to predict/approximate values determined by expt (our 'objective function')
    def get_predictions(self, X): # X = list of parameter sets - each parameter set should be list with len(params) entries.
    	# catch any warning generated when making a prediction
    	with catch_warnings():
    		# ignore generated warnings
            simplefilter("ignore")
            if type(X[0]) is int:
                return [self.fit_model.predict(X, return_std=True)]
            else:
                 [self.fit_model.predict(x, return_std=True) for x in X]
                 
    # probability of improvement acquisition function
    def sample_probabilities(self, X, Xsamples):
    	# calculate the best surrogate score found so far
    	yhat, _ = self.get_predictions(X)
    	best = max(yhat)
    	# calculate mean and stdev via surrogate function
    	mu, std = self.get_predictions(Xsamples)
    	mu = mu[:, 0]
    	# calculate the probability of improvement
    	probs = stats.norm.cdf((mu - best) / (std+1E-9))
    	return probs
     
    # optimize the acquisition function
    def suggest_optimal_params(self, X, N_psets = 1):
        N_guesses=100
        if N_psets > 1:
            psets=[]
        
        for _ in range(N_psets):
        	# random search, generate random samples
            Xsamples = self.generate_params(N=N_guesses, return_trials = True)
            # calculate the acquisition function for each sample
            scores = self.sample_probabilities(X, Xsamples)
            # locate the index of the most negative scores
            ix = np.argmin(scores)
            if N_psets > 1:
                psets.append(Xsamples[ix])
                
        if N_psets == 1:
            return Xsamples[ix]
        else:
            return psets
        
    
    def train_model(self):
        # See https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPRegressor.html
        self.fit_model.fit(self.history['trials'], self.history['cost']) # might need np.array(self.history['trials'])
        
    def generate_params(self, N=1, stdevs = None, return_trials = False):
        if return_trials:
            trials = [[] for _ in range(N)]
            
        if (stdevs != None) and (len(stdevs) != len(self.params)):
            stdevs = None
         
        for i, p in enumerate(self.params):
            # Stand-in functions to determine the min/max allowed values for the parameter
            # In reality, these need to be drawn from the relevant spinbox or w/e
            rangemin = p.rangemin
            rangemax = p.rangemax
            stepsize = p.stepsize # similarly, smallest unit distance between adjacent vals for the spinbox in question
            
            p_mean = self.get_current_value(p) # Stand-in function to retrieve current val; 
                                              #    assumes that current parameter value is 'best so far'
            if not stdevs:
                p_std = self.get_default_std(p) # I'm not sure what the best choice for a standard deviation
                                                 #     is, here. Will probably depend on type. AOM freq +-5, Power +- 0.25 etc?
            else:
                p_std = stdevs[i]
                
            trunc_gaussian = stats.truncnorm(rangemin, rangemax, loc=p_mean, scale=p_std)
            p_vals = [round(x/stepsize)*stepsize for x in trunc_gaussian.rvs(N)]
            
            p.vals_to_try = p_vals
            
            if return_trials:
                for j in range(N):
                    trials[j].append(p_vals[j])
        if return_trials:
            return trials

    def obtain_training_data(self, n_iterations,doGo):
        
        # So the question is, do we draw our training samples independently,
        #       or sample randomly to begin with and then select new samples 
        #       for training based on results, to 'get best idea' of underlying model?
        # 
        # This arrangement draws all sets of parameters separately at the beginning,
        #       then iterates expt to establish costs for each set of parameters.
        #       Im not sure how to include cost variability/uncertainty in model
        #
        # Can also generate new training params during loop if we want something 'smarter'
        
        self.generate_params(self.params, N = n_iterations)
        
        for i in range(n_iterations):
            
            cost = self.run_expt() # Runs expt to find total atoms, peak optical density
            
            histvec=[]
            for p in self.params:
                histvec.append(p.vals_to_try[0])
                self.p.history.append(p.vals_to_try.pop(0))
                
            self.history['trials'].append(histvec)
            self.history['cost'].append(cost)
            
        self.train_model()
            
    def iterate(self, N=1):
        for _ in range(N):
            params_to_try = self.suggest_optimal_params(self.history['trials'])
            cost = self.run_expt(params_to_try)
            
            self.history['trials'].append(params_to_try)
            self.history['cost'].append(cost)
            self.train_model()
        

    def run_expt(self, params=None): 
        # Run expt and return the atom number, peak optical density
        # This is clearly a stand-in for interfacing with SEC to adjust stage values, run expt and extract numbers from the resulting image
        if params:
            self.adjust_expt_params(params)
        else:
            self.adjust_expt_params(self.params)
        self.doGo()
        
        N, OD_peak = self.obtain_expt_result()
        cost = self.cost_function(N, OD_peak) # Establishes associated cost, and saves it
        
        return cost
