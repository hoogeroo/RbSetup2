#!/usr/local/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 16 15:00:25 2016

This file creates the main window of the control program.
It reads and writes the data as fits files.


@author: mhoo027
"""

import sys
import os
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import astropy.io.fits as fits
import numpy as np
import matplotlib.pyplot as plt
from functools import partial
#from qmsbox import *
from allboxes import *
import DAQ
import blackfly
#import multigo_window as multigo
import glob
import multigo_window as mg


defaultfilename="defaultb.fit"

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        # Creating the main window
        # First we see if the default file exists, and if yes, we take the number of rows and columns from it.
        # If no, we make assumptions
        if os.path.exists(defaultfilename):
            fitsfile=fits.open(defaultfilename)
            headers=fitsfile[0].header
            ncols=headers['NCOLS']
            nrows=headers['NROWS']
            nDACs=headers['NDACS']
            nAOMs=headers['NAOMS']
            fitsfile.close()
            self.CW = allboxes(nDACs,nAOMs,ncols)
            self.myload(defaultfilename)
        else:
            nDACs=8
            nAOMs=6
            ncols=8
            nrows=nDACs+2*nAOMs
            self.CW = allboxes(nDACs,nAOMs,ncols)
        self.setCentralWidget(self.CW) # the central widget is everything in the main window
        self.setWindowTitle("Simple Experiment Controller")
        # filling up a menu bar
        bar = self.menuBar()
        bar.setNativeMenuBar(False)
        # File menu
        file_menu = bar.addMenu(' File')
        # adding actions to file menu
        open_action = QAction('Open', self)
        save_action = QAction('Save as default', self)
        save_as_action= QAction('Save',self)
        close_action = QAction('Close', self)
        file_menu.addAction(open_action)
        file_menu.addAction(save_action)
        file_menu.addAction(save_as_action)
        file_menu.addAction(close_action)
        # Edit menu
        edit_menu = bar.addMenu(' Edit')
        self.column_dup = edit_menu.addMenu('Duplicate Column')
        self.coldup_actions=[]
        for i in range(self.CW.ntimes):
            self.coldup_actions.append(QAction('Column '+str(i+1),self))
            self.column_dup.addAction(self.coldup_actions[-1])
            self.coldup_actions[-1].triggered.connect(partial(self.CW.DupCol,i))
        self.column_del = edit_menu.addMenu('Delete Column')
        self.coldel_actions=[]
        for i in range(self.CW.ntimes):
            self.coldel_actions.append(QAction('Column '+str(i+1),self))
            self.column_del.addAction(self.coldel_actions[-1])
            self.coldel_actions[-1].triggered.connect(partial(self.CW.DelCol,i+1))
        # adding actions to edit menu
        undo_action = QAction('Undo', self)
        redo_action = QAction('Redo', self)
        add_action = QAction('Add Column on Right',self)
        insert_action = QAction('Insert Column before Cursor',self)
        remove_action= QAction('Remove Column at Cursor',self)
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)
        edit_menu.addAction(add_action)
        go_menu=bar.addMenu('Go')
        go_action=QAction('Go',self)
        go_menu.addAction(go_action)
        multigo_action=QAction('Multigo',self)
        go_menu.addAction(multigo_action)
        multigo_options=QAction('MultiGo parameters',self)
        go_menu.addAction(multigo_options)
        multigo_options.triggered.connect(self.mgmenu)
        go_action.triggered.connect(self.CW.GoAction)
        self.filename=defaultfilename
        option_menu=bar.addMenu('Options')
        self.blackfly_action=QAction('Blackfly_Camera',checkable=True)
        option_menu.addAction(self.blackfly_action)
        self.princeton_action=QAction('Princeton Camera',checkable=True)
        option_menu.addAction(self.princeton_action)
        # use `connect` method to bind signals to desired behavior
        close_action.triggered.connect(self.close)
        save_action.triggered.connect(self.mysaveaction)
        open_action.triggered.connect(self.myopenaction)
        save_as_action.triggered.connect(self.saveasaction)
        add_action.triggered.connect(self.CW.AddCol)
        self.blackfly_action.triggered.connect(self.initblackfly)
        self.setMaximumHeight(800)
        self.CW.fill_MG_files() #Add multigo files
#==============================================================================================================
#==============================================================================================================
    def mgmenu(self):
        mg.multigomenu(self.CW.MGPanel)
#==============================================================================================================
#==============================================================================================================
    def initblackfly(self):  # Blackfly camera initialisation
        self.bfcam=blackfly.blackfly()
        self.blackfly_action.setChecked(True)
#==============================================================================================================
#==============================================================================================================
#    def multigomenu(self): # Open Multigo dialog. Something odd is that it takes two clicks to close.
#        filename=self.CW.MGPanel.cbExpKind.currentText()+".mgo"
#        dlg=mg.MultiGoDialog(filename)
#        if dlg.exec_():
#          print('success')
#          dlg.mysave()
#          #self.addMGFiles()
#          dlg.close()
#        else:
#          print("fail")
#          dlg.close()

#    def addMGFiles(self): # these are the custom multigo files. There are some issues with the multigo
#        flist=sorted(glob.glob("*.mgo"))
#        for item in flist:
#          sitem=item[:-4]
#          self.CW.MGPanel.cbExpKind.addItem(sitem)

#==============================================================================================================
#==============================================================================================================
    def myopenaction(self): # Action for file open
        fname,desc = QFileDialog.getOpenFileName(self, 'Open file', datapath,"FITS files (*.fit)")
        #print(fname)
        #fname='defaultb.fit'
        if os.path.exists(fname):
            self.myload(fname)
            self.filename=fname
#==============================================================================================================
#==============================================================================================================
    def mysaveaction(self): # Action for file save as default
        if os.path.exists(defaultfilename):
            os.remove(defaultfilename)
        self.mysave(defaultfilename)
#==============================================================================================================
#==============================================================================================================
    def saveasaction(self): # Action for file save
        mydate=datetime.now().strftime('%Y%m%d%H%M')
        #name,path = QFileDialog.getSaveFileName(self, 'Save File', preferredname, myfilter)
        #print(name)
        path=datapath+'/'+mydate
        if not (os.path.exists(path)):
          os.mkdir(path)
          myid=0
        else:
          files=glob.glob(path)
          nfiles=len(files)
          myid=nfiles
        name=path+'/Data_'+str(myid)+'.fit'
        self.mysave(name)
#==============================================================================================================
#==============================================================================================================
    def mysave(self,filename):
        while os.path.exists(filename):
            fn1=filename.split('.')
            filename=fn1[0]+'_1'+fn1[1]
            print('New filename:',filename)
        
        if (self.blackfly_action.isChecked()):
          Imhdu=fits.PrimaryHDU(self.bfcam.data)
        else:
          Imhdu=fits.PrimaryHDU(np.arange(100.0))
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/          
        prihdr=Imhdu.header
        prihdr['NCOLS']=(self.CW.ntimes, 'Number of Columns')
        prihdr['NROWS']=(self.CW.nrows, 'Number of Rows')
        prihdr['NDACS']=(self.CW.nDACs, 'Number of DACs')
        prihdr['NAOMS']=(self.CW.nAOMs, 'Number of AOMs')
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        columns,curves,DIOstate = self.CW.Stages.store()
        
        Tabhdu=fits.BinTableHDU.from_columns(columns)
        Tab2hdu=fits.BinTableHDU.from_columns(curves)
        Tab4hdu=fits.BinTableHDU.from_columns(DIOstate)

        edvals=[self.CW.eagledac.Eagle_boxes[i].value() for i in range(24)]
            
        Tab3hdu=fits.BinTableHDU.from_columns(\
          [fits.Column('Eagle DAC values',array=np.array(edvals),format='E')])
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        hdu1=fits.HDUList([Imhdu,Tabhdu,Tab2hdu,Tab3hdu,Tab4hdu])
        hdu1.writeto(filename)
#==============================================================================================================
#==============================================================================================================
    def myload(self,filename):
        from astropy.table import Table
        fitsfile=fits.open(filename)
        headers=fitsfile[0].header
        ncols=headers['NCOLS']
        nrows=headers['NROWS']
        tabledata=fitsfile[1].data
        curvedata=fitsfile[2].data
        DIOstate=fitsfile[4].data
        
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        self.CW.Stages.populate(tabledata,curvedata,DIOstate)
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        eagledata=fitsfile[3].data
        for i in range(24):
            self.CW.eagledac.Eagle_boxes[i].setValue(eagledata[i][0])
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        #\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
        fitsfile.close()
#==============================================================================================================
#==============================================================================================================


def main():
   app = QApplication(sys.argv)
   mw = MainWindow()
   #ex = spindemo()
   mw.show()
   sys.exit(app.exec_())

if __name__ == '__main__':
   main()
